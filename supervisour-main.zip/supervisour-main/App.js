import React from 'react';
import Navigation from './Src/Navigation/index';

function App() {
  return (
    <Navigation />
  )
}
export default App;
